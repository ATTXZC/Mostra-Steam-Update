import React from "react";
import "./Foooter.css";

function Foooter() {
    return (
        <footer>
            <p className="textinho-footer">&copy; Ecolife Todos os Direitos Reservados 2024</p>
        </footer>
    );
}

export default Foooter;
