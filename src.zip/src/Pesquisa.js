import React from "react";
import "./Foooter.css";

function Pesquisa() {
    return (
        <input className="Hox" type="search"/>
    );
}

export default Pesquisa;
